jQuery(document).ready(function(){
jQuery("a[rel^='prettyPhoto']").prettyPhoto({theme: 'pp_default',show_title: false,});
});

// Default theme - 'pp_default'
// Facebook inspired theme - 'facebook'
// Dark rounded semi-transparent theme - 'dark_rounded'
// Dark square semi-transparent theme - 'dark_square'
// Light square theme - 'light_square'
// Light rounded theme - 'light_rounded'

