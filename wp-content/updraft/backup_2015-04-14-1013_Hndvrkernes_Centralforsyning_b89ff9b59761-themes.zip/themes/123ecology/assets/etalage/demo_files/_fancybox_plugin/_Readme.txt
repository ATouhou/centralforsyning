Fancybox is not related to Frique/Etalage in any way and is merely included to demonstrate the optional cooperation with Etalage (see example_fancybox.html).

Home of the Fancybox plugin:
http://fancybox.net/