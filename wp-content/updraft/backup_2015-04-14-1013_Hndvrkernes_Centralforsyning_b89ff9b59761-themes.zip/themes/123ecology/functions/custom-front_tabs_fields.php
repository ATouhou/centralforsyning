<?php
$fronttabs_meta_boxes = 
array(

"select-icon" => array(
"name" => "select-icon",
"type" => "select",
"std" => 1,
"options" => array (array( "value" => "none", "text" => "none"),
array('value' => 'Add-plus', 'text' => 'Add-plus'),

array('value' => 'Add-To-Cart', 'text' => 'Add-To-Cart'),

array('value' => 'Archive-empty', 'text' => 'Archive-empty'),

array('value' => 'Archive-Full', 'text' => 'Archive-Full'),

array('value' => 'Arrow-1', 'text' => 'Arrow-1'),

array('value' => 'Arrow-2', 'text' => 'Arrow-2'),

array('value' => 'Back', 'text' => 'Back'),

array('value' => 'Baloons', 'text' => 'Baloons'),

array('value' => 'Barcode', 'text' => 'Barcode'),

array('value' => 'Battery-0', 'text' => 'Battery-0'),

array('value' => 'Battery-1', 'text' => 'Battery-1'),

array('value' => 'Battery-2', 'text' => 'Battery-2'),

array('value' => 'Battery-3', 'text' => 'Battery-3'),

array('value' => 'Bird', 'text' => 'Bird'),

array('value' => 'Bluetooth', 'text' => 'Bluetooth'),

array('value' => 'Books', 'text' => 'Books'),

array('value' => 'Bowtie', 'text' => 'Bowtie'),

array('value' => 'Brightness', 'text' => 'Brightness'),

array('value' => 'Brush', 'text' => 'Brush'),

array('value' => 'Bus', 'text' => 'Bus'),

array('value' => 'Calculator', 'text' => 'Calculator'),

array('value' => 'Calendar-1', 'text' => 'Calendar-1'),

array('value' => 'Calendar-2', 'text' => 'Calendar-2'),

array('value' => 'Camera', 'text' => 'Camera'),

array('value' => 'Car-1', 'text' => 'Car-1'),

array('value' => 'Car-2', 'text' => 'Car-2'),

array('value' => 'Cassette', 'text' => 'Cassette'),

array('value' => 'Chat-bubbles', 'text' => 'Chat-bubbles'),

array('value' => 'Checklist', 'text' => 'Checklist'),

array('value' => 'Chip', 'text' => 'Chip'),

array('value' => 'Claw', 'text' => 'Claw'),

array('value' => 'Clock-1', 'text' => 'Clock-1'),

array('value' => 'Clock-2', 'text' => 'Clock-2'),

array('value' => 'Cloud-offline', 'text' => 'Cloud-offline'),

array('value' => 'Cloud-online', 'text' => 'Cloud-online'),

array('value' => 'Cloud-sync', 'text' => 'Cloud-sync'),

array('value' => 'Cloud', 'text' => 'Cloud'),

array('value' => 'Cloverleaf', 'text' => 'Cloverleaf'),

array('value' => 'Cog-1', 'text' => 'Cog-1'),

array('value' => 'Cog-2', 'text' => 'Cog-2'),

array('value' => 'Cog-3', 'text' => 'Cog-3'),

array('value' => 'Cogs', 'text' => 'Cogs'),

array('value' => 'Command', 'text' => 'Command'),

array('value' => 'Comments', 'text' => 'Comments'),

array('value' => 'Compass', 'text' => 'Compass'),

array('value' => 'Console', 'text' => 'Console'),

array('value' => 'Cookie', 'text' => 'Cookie'),

array('value' => 'Credit-Card', 'text' => 'Credit-Card'),

array('value' => 'Delete-minus', 'text' => 'Delete-minus'),

array('value' => 'Delicous', 'text' => 'Delicous'),

array('value' => 'deviantart', 'text' => 'deviantart'),

array('value' => 'Diamond', 'text' => 'Diamond'),

array('value' => 'digg', 'text' => 'digg'),

array('value' => 'Disk', 'text' => 'Disk'),

array('value' => 'Dislike', 'text' => 'Dislike'),

array('value' => 'Documents-1', 'text' => 'Documents-1'),

array('value' => 'Documents-2', 'text' => 'Documents-2'),

array('value' => 'Dreieck', 'text' => 'Dreieck'),

array('value' => 'Dribbble-2', 'text' => 'Dribbble-2'),

array('value' => 'Dribbble', 'text' => 'Dribbble'),

array('value' => 'Drop', 'text' => 'Drop'),

array('value' => 'Egg', 'text' => 'Egg'),

array('value' => 'Eject', 'text' => 'Eject'),

array('value' => 'Facebook', 'text' => 'Facebook'),

array('value' => 'Fast-Forward', 'text' => 'Fast-Forward'),

array('value' => 'Feather', 'text' => 'Feather'),

array('value' => 'Filmstrip', 'text' => 'Filmstrip'),

array('value' => 'Flask', 'text' => 'Flask'),

array('value' => 'Flickr', 'text' => 'Flickr'),

array('value' => 'Folder', 'text' => 'Folder'),

array('value' => 'Foot', 'text' => 'Foot'),

array('value' => 'Forrst', 'text' => 'Forrst'),

array('value' => 'Forward', 'text' => 'Forward'),

array('value' => 'Full-screen', 'text' => 'Full-screen'),

array('value' => 'Game-controller', 'text' => 'Game-controller'),

array('value' => 'Genius', 'text' => 'Genius'),

array('value' => 'Google-plus', 'text' => 'Google-plus'),

array('value' => 'Graph', 'text' => 'Graph'),

array('value' => 'Hand', 'text' => 'Hand'),

array('value' => 'Headphones', 'text' => 'Headphones'),

array('value' => 'Hearts', 'text' => 'Hearts'),

array('value' => 'Help', 'text' => 'Help'),

array('value' => 'High-Heel', 'text' => 'High-Heel'),

array('value' => 'Home', 'text' => 'Home'),

array('value' => 'Info', 'text' => 'Info'),

array('value' => 'Internet', 'text' => 'Internet'),

array('value' => 'Kanye-Glasses', 'text' => 'Kanye-Glasses'),

array('value' => 'Key', 'text' => 'Key'),

array('value' => 'last.fm', 'text' => 'last.fm'),

array('value' => 'Like', 'text' => 'Like'),

array('value' => 'Link', 'text' => 'Link'),

array('value' => 'linkin', 'text' => 'linkin'),

array('value' => 'List', 'text' => 'List'),

array('value' => 'Lock', 'text' => 'Lock'),

array('value' => 'Magnet', 'text' => 'Magnet'),

array('value' => 'Mail-Plane', 'text' => 'Mail-Plane'),

array('value' => 'Mail', 'text' => 'Mail'),

array('value' => 'Marker-1', 'text' => 'Marker-1'),

array('value' => 'Marker-2', 'text' => 'Marker-2'),

array('value' => 'Minus', 'text' => 'Minus'),

array('value' => 'Monitor', 'text' => 'Monitor'),

array('value' => 'Monster', 'text' => 'Monster'),

array('value' => 'Mouse', 'text' => 'Mouse'),

array('value' => 'Moustache', 'text' => 'Moustache'),

array('value' => 'Next', 'text' => 'Next'),

array('value' => 'Pacman', 'text' => 'Pacman'),

array('value' => 'Paint-document', 'text' => 'Paint-document'),

array('value' => 'Paperclip', 'text' => 'Paperclip'),

array('value' => 'Pause', 'text' => 'Pause'),

array('value' => 'Paypal', 'text' => 'Paypal'),

array('value' => 'Pen', 'text' => 'Pen'),

array('value' => 'Pencil-and-Brush', 'text' => 'Pencil-and-Brush'),

array('value' => 'Pencil', 'text' => 'Pencil'),

array('value' => 'People-1', 'text' => 'People-1'),

array('value' => 'People-2', 'text' => 'People-2'),

array('value' => 'Play-1', 'text' => 'Play-1'),

array('value' => 'Play-2', 'text' => 'Play-2'),

array('value' => 'Plus', 'text' => 'Plus'),

array('value' => 'Pokéball', 'text' => 'Pokéball'),

array('value' => 'Previous', 'text' => 'Previous'),

array('value' => 'Puzzle', 'text' => 'Puzzle'),

array('value' => 'Rating-minus', 'text' => 'Rating-minus'),

array('value' => 'Rating-plus', 'text' => 'Rating-plus'),

array('value' => 'Recycling', 'text' => 'Recycling'),

array('value' => 'Rewind', 'text' => 'Rewind'),

array('value' => 'RSS', 'text' => 'RSS'),

array('value' => 'Scaling', 'text' => 'Scaling'),

array('value' => 'Scissors', 'text' => 'Scissors'),

array('value' => 'Screenshot', 'text' => 'Screenshot'),

array('value' => 'Search', 'text' => 'Search'),

array('value' => 'Searching', 'text' => 'Searching'),

array('value' => 'Shield', 'text' => 'Shield'),

array('value' => 'Shit', 'text' => 'Shit'),

array('value' => 'Shoe', 'text' => 'Shoet'),

array('value' => 'Shopping-Basket', 'text' => 'Shopping-Basket'),

array('value' => 'Shopping-cart-1', 'text' => 'Shopping-cart-1'),

array('value' => 'Shopping-Cart-2', 'text' => 'Shopping-Cart-2'),

array('value' => 'Shuffle', 'text' => 'Shuffle'),

array('value' => 'Shut-down', 'text' => 'Shut-down'),

array('value' => 'Skype-absent', 'text' => 'Skype-absent'),

array('value' => 'Skype-offline', 'text' => 'Skype-offline'),

array('value' => 'Skype-online', 'text' => 'Skype-online'),

array('value' => 'Skype', 'text' => 'Skype'),

array('value' => 'Sound-note', 'text' => 'Sound-note'),

array('value' => 'Spinner', 'text' => 'Spinner'),

array('value' => 'Star', 'text' => 'Star'),

array('value' => 'Stop', 'text' => 'Stop'),

array('value' => 'Sync', 'text' => 'Sync'),

array('value' => 'Tags', 'text' => 'Tags'),

array('value' => 'Target', 'text' => 'Target'),

array('value' => 'Telephone', 'text' => 'Telephone'),

array('value' => 'Television', 'text' => 'Television'),

array('value' => 'Thunder-1', 'text' => 'Thunder-1'),

array('value' => 'Thunder-2', 'text' => 'Thunder-2'),

array('value' => 'Tools', 'text' => 'Tools'),

array('value' => 'Trash', 'text' => 'Trash'),

array('value' => 'Truck', 'text' => 'Truck'),

array('value' => 'Tumblr', 'text' => 'Tumblr'),

array('value' => 'Twitter-1', 'text' => 'Twitter-1'),

array('value' => 'Twitter-2', 'text' => 'Twitter-2'),

array('value' => 'Umbrella-1', 'text' => 'Umbrella-1'),

array('value' => 'Umbrella-2', 'text' => 'Umbrella-2'),

array('value' => 'Under-Construction', 'text' => 'Under-Construction'),

array('value' => 'Unlock', 'text' => 'Unlock'),

array('value' => 'Upload_Download', 'text' => 'Upload_Download'),

array('value' => 'Video', 'text' => 'Video'),

array('value' => 'View', 'text' => 'View'),

array('value' => 'Vimeo', 'text' => 'Vimeo'),

array('value' => 'Volumen-0', 'text' => 'Volumen-0'),

array('value' => 'Volumen-1', 'text' => 'Volumen-1'),

array('value' => 'Volumen-2', 'text' => 'Volumen-2'),

array('value' => 'Wallpaper', 'text' => 'Wallpaper'),

array('value' => 'Warning', 'text' => 'Warning'),

array('value' => 'Yahoo', 'text' => 'Yahoo'),

array('value' => 'Yin-and-Yang', 'text' => 'Yin-and-Yang'),

array('value' => 'Youtube', 'text' => 'Youtube'),

array('value' => 'Zip', 'text' => 'Zip'),

array('value' => 'Zoom-in', 'text' => 'Zoom-in'),

array('value' => 'Zoom-out', 'text' => 'Zoom-out')),
"description" => "select an icon for tab",
"title" => "Select Icon")

);

/* meta_boxes
================================================== */
function fronttabs_meta_boxes() {
global $post, $fronttabs_meta_boxes;
	
	foreach($fronttabs_meta_boxes as $meta_box) {
		
        if($meta_box['name']){
    		echo'<input type="hidden" name="'.$meta_box['name'].'_noncename" id="'.$meta_box['name'].'_noncename" value="'.wp_create_nonce( plugin_basename(__FILE__) ).'" />';
    		
    		echo'<div style="display:block;"><h4 style="display:inline-block;">'.$meta_box['title'].'</h4>';
            if($meta_box['description']){
               echo'<p style="font-size:90%;display:inline-block;">&nbsp;('.$meta_box['description'].')</p></div>'; 
            }else{
               echo'</div>'; 
            }
        }
		
		if( $meta_box['type'] == "input" ) { 
		
			$meta_box_value = get_post_meta($post->ID, $meta_box['name'].'_value', true);
		
			if($meta_box_value == "")
				$meta_box_value = $meta_box['std'];
		
			echo'<input type="text" name="'.$meta_box['name'].'_value" value="'.$meta_box_value.'" style="width:90%"/><br />';
            
		} elseif ( $meta_box['type'] == "select" ) {
			
			echo'<select name="'.$meta_box['name'].'_value">';
			
			foreach ($meta_box['options'] as $option) {
                
				echo'<option value="';
                echo $option['value'];
                echo'"';
				if ( get_post_meta($post->ID, $meta_box['name'].'_value', true) == $option['value'] ) { 
					echo ' selected="selected"'; 
				} elseif ( $option == $meta_box['std'] ) { 
					echo ' selected="selected"'; 
				} 
				echo'>'. $option['text'] .'</option>';
			
			} 
			
			echo'</select>';
        }
	}

}

/* enable meta_boxes
================================================== */
function create_fronttabs_meta_box() {
global $theme_name, $fronttabs_meta_boxes;
	if (function_exists('add_meta_box') ) {
	add_meta_box( 'fronttabs-meta-boxes', __('Front Tabs Options', GETTEXT_DOMAIN), 'fronttabs_meta_boxes', 'front_tabs', 'normal', 'high' );
	}
}

/* update meta_boxes
================================================== */
function save_fronttabs_postdata( $post_id ) {
	global $post, $fronttabs_meta_boxes;  
		foreach($fronttabs_meta_boxes as $meta_box) {  
 
    /*if (isset($_POST[$meta_box['name'].'_noncename'])){
		if ( !wp_verify_nonce( $_POST[$meta_box['name'].'_noncename'], plugin_basename(__FILE__) )) {  
			return $post_id;  
		}  
    }*/
    
	if ( !wp_verify_nonce( $_POST[$meta_box['name'].'_noncename'], plugin_basename(__FILE__) )) {  
		return $post_id;  
	}  
	
	if ( 'page' == $_POST['post_type'] ) {  
		if ( !current_user_can( 'edit_page', $post_id ))  
		return $post_id;  
	} else {  
		if ( !current_user_can( 'edit_post', $post_id ))  
	return $post_id;
	}  

    $data = $_POST[$meta_box['name'].'_value']; 
	
	if(get_post_meta($post_id, $meta_box['name'].'_value') == "")  
		add_post_meta($post_id, $meta_box['name'].'_value', $data, true);  
		elseif($data != get_post_meta($post_id, $meta_box['name'].'_value', true))  
	update_post_meta($post_id, $meta_box['name'].'_value', $data);  
		elseif($data == "")  
	delete_post_meta($post_id, $meta_box['name'].'_value', get_post_meta($post_id, $meta_box['name'].'_value', true));  
	}
	
}
add_action('admin_menu', 'create_fronttabs_meta_box');
add_action('save_post', 'save_fronttabs_postdata');
?>