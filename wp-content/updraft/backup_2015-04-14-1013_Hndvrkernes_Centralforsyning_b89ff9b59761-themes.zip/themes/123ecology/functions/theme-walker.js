
jQuery(function($){
	
	$(".nav-type").hide()
	$(".menu-item-depth-0 .nav-type").show();
	
	
	});